# A Python package for getting products from stripe through stripe API Secret Key

Run test.py and it will ask for Stripe API Secret Key in Terminal
Put Stripe API key and you will get all the products list in Terminal and you will also
get products in Json Format.